#leap year
def isleapYear(Year):
  if(Year % 4==0 and Year % 100!=0)or Year % 400==0:
     return True
  else:
    return False
Year=2012
if isleapYear(Year):
  print("{} is a loop year".format(Year))
else:
  print("{}is not aleap year".format(Year))